from .stamps import get_cmap
from .helpers import apply_stamp, Stamp
from . import stamps
from . import helpers
